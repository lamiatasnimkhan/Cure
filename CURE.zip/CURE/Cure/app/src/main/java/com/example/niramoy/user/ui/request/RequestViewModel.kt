package com.example.niramoy.user.ui.request

import androidx.lifecycle.ViewModel

class RequestViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}