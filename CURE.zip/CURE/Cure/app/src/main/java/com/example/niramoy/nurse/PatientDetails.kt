package com.example.niramoy.nurse

data class PatientDetails(
    val details: String,
   // val duration: String,

    val date: String,
    val location: String,

    val review: String
)