package com.example.niramoy.admin



data class User(
    val name: String,
    val nationalId: String,
    val certificate: String,
    val specialField: String
)
